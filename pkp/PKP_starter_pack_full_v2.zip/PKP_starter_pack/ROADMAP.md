v1.1: JSONL events; v1.2: typed edges; v1.3: timeseries; v2.0: graph backend
