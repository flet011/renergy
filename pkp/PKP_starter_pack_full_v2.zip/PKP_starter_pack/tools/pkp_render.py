#!/usr/bin/env python3
import json, sys, pathlib, html, datetime

CSS = """
body { font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif; margin: 24px; }
h1 { margin-bottom: 0; }
.small { color: #666; font-size: 12px; }
section { margin: 24px 0; }
table { border-collapse: collapse; width: 100%; }
th, td { border: 1px solid #ddd; padding: 8px; }
th { background: #f7f7f7; text-align: left; }
.badge { display: inline-block; padding: 2px 8px; border-radius: 10px; background:#eef; margin-right:6px; }
.kv { display: grid; grid-template-columns: 220px 1fr; gap: 6px 12px; }
"""

def rowify(d):
    return "".join(f"<div><b>{html.escape(str(k))}</b></div><div>{html.escape(str(v))}</div>" for k,v in d.items())

def table(items, cols):
    if not items: return "<em>None</em>"
    head = "".join(f"<th>{html.escape(c)}</th>" for c in cols)
    rows = ""
    for it in items:
        rows += "<tr>" + "".join(f"<td>{html.escape(str(it.get(c,'')))}</td>" for c in cols) + "</tr>"
    return f"<table><thead><tr>{head}</tr></thead><tbody>{rows}</tbody></table>"

def main():
    if len(sys.argv) < 3:
        print("Usage: pkp_render.py <input_node.json> <output.html>")
        sys.exit(1)
    inp = pathlib.Path(sys.argv[1])
    out = pathlib.Path(sys.argv[2])
    data = json.loads(inp.read_text())
    meta = data.get("meta",{})
    node = data.get("node",{})
    ctx = data.get("context",{})
    sig = data.get("signals",{})
    news = data.get("news",[])
    risks = data.get("risks",[])
    actions = data.get("actions",[])
    sources = data.get("sources",[])

    html_doc = f"""
<!doctype html>
<html><head><meta charset='utf-8'><title>PKP: {html.escape(node.get('id',''))}</title>
<style>{CSS}</style></head>
<body>
<h1>{html.escape(node.get('name',''))} <span class='small'>({html.escape(node.get('id',''))})</span></h1>
<div class='small'>Schema {html.escape(meta.get('schema_version',''))} • Domain {html.escape(meta.get('domain',''))} • Confidence {meta.get('confidence','')} • Updated {html.escape(meta.get('created_at',''))}</div>

<section>
  <h2>Thesis</h2>
  <p>{html.escape(node.get('thesis',''))}</p>
  <div class='kv'>
    {rowify({"Layer":node.get("layer",""),"Type":node.get("type",""),"Horizon":node.get("time_horizon","")})}
  </div>
</section>

<section>
  <h2>Picks & Shovels</h2>
  {table(ctx.get("picks_shovels",[]), ["id","name","role","edge_type","weight"])}
</section>

<section>
  <h2>Edges</h2>
  {table(ctx.get("edges",[]), ["from","to","type","weight"])}
</section>

<section>
  <h2>Undercurrents</h2>
  {table(ctx.get("undercurrents",[]), ["name","direction","rationale"])}
</section>

<section>
  <h2>Signals — Metrics</h2>
  {table(sig.get("metrics",[]), ["name","unit","current"])}
  <h2>Signals — Events</h2>
  {table(sig.get("events",[]), ["date","type","impact","source"])}
</section>

<section>
  <h2>News</h2>
  {table(news, ["date","headline","sentiment","source"])}
</section>

<section>
  <h2>Risks</h2>
  {table(risks, ["name","likelihood","severity"])}
</section>

<section>
  <h2>Actions</h2>
  {table(actions, ["type","what","rule","notify"])}
</section>

<section>
  <h2>Sources</h2>
  {table(sources, ["name","url"])}
</section>

<footer class='small'>Generated {datetime.datetime.utcnow().isoformat()}Z • PKP Renderer</footer>
</body></html>
"""
    out.write_text(html_doc)
    print(f"Wrote {out}")

if __name__ == "__main__":
    main()
